export interface Adress{
    cep: string;
    logradouro: string;
    complemento: string;
    bairro: string;
    uf: string;
    unidade: any;
    ibge: string;
    gia: string;
}